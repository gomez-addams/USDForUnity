#pragma once


template<bool Value>
struct VtAlignedAllocatorBool
{
    static const bool value = Value;
};

VT_API void* VtAlignedMalloc(size_t size, size_t align);
VT_API void  VtAlignedFree(void *addr);

template<class T, int Alignment = 0x10>
class VtAlignedAllocator
{
public:
    typedef T                                    value_type;
    typedef T *                                  pointer;
    typedef const T *                            const_pointer;
    typedef T &                                  reference;
    typedef const T &                            const_reference;
    typedef std::size_t                          size_type;
    typedef std::ptrdiff_t                       difference_type;

    static const int alignment = Alignment;

    //!Obtains an VtAlignedAllocator that allocates
    //!objects of type T2
    template<class T2>
    struct rebind
    {
        typedef VtAlignedAllocator<T2> other;
    };

    //!Default constructor
    //!Never throws
    VtAlignedAllocator()
    {}

    //!Constructor from other VtAlignedAllocator.
    //!Never throws
    VtAlignedAllocator(const VtAlignedAllocator &)
    {}

    //!Constructor from related VtAlignedAllocator.
    //!Never throws
    template<class T2>
    VtAlignedAllocator(const VtAlignedAllocator<T2> &)
    {}

    //!Allocates memory for an array of count elements.
    //!Throws std::bad_alloc if there is no enough memory
    pointer allocate(size_type size)
    {
        return static_cast<T*>(VtAlignedMalloc(size * sizeof(T), alignment));
    }

    //!Deallocates previously allocated memory.
    //!Never throws
    void deallocate(pointer ptr, size_type size)
    {
        VtAlignedFree(ptr);
    }

    //!Returns the maximum number of elements that could be allocated.
    //!Never throws
    size_type max_size() const
    {
        return size_type(-1) / sizeof(T);
    }

    //!Swaps two allocators, does nothing
    //!because this VtAlignedAllocator is stateless
    friend void swap(VtAlignedAllocator &, VtAlignedAllocator &)
    {}

    //!An VtAlignedAllocator always compares to true, as memory allocated with one
    //!instance can be deallocated by another instance
    friend bool operator==(const VtAlignedAllocator &, const VtAlignedAllocator &)
    {
        return true;
    }

    //!An VtAlignedAllocator always compares to false, as memory allocated with one
    //!instance can be deallocated by another instance
    friend bool operator!=(const VtAlignedAllocator &, const VtAlignedAllocator &)
    {
        return false;
    }
};