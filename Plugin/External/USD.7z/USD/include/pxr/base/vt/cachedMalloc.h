#pragma  once

#include <tbb/spin_mutex.h>

class VtCachedMallocImpl
{
public:
    VT_API VtCachedMallocImpl(size_t bin_size, size_t block_size);
    VT_API void* Allocate();
    VT_API void Free(void *addr);

private:
    size_t _bin_size = 0;
    size_t _block_size = 0;
    void *_head = nullptr;
    tbb::spin_mutex _mutex;
};

VT_API void* VtCachedMalloc(size_t size);
VT_API void VtCachedFree(size_t size, void *addr);

#ifdef USD_ENABLE_CACHED_NEW
    #define VT_DEFINE_CACHED_OPERATOR_NEW(T)\
        static VtCachedMallocImpl& _GetAllocator() { static VtCachedMallocImpl _impl(sizeof(T), 256); return _impl; }\
        void* operator new (size_t) { return _GetAllocator().Allocate(); }\
        void operator delete (void* addr) { _GetAllocator().Free(addr); }
#else
    #define VT_DEFINE_CACHED_OPERATOR_NEW(T)
#endif
